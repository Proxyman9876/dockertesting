# Mini Snake Game in Docker

This project is a browser-based Snake game built with Python and Flask, then containerized with Docker.

## What it does
The application starts a local web server and serves a playable Snake game in the browser.

## Dependency used
- Flask

## Project files
- `app.py` - Flask application
- `requirements.txt` - Python dependency list
- `Dockerfile` - Docker container setup
- `templates/index.html` - Snake game frontend

## Build the Docker image

```bash
docker build -t mini-snake .